1. Delete existing angular.json file and replace by given angular.json.
2. Copy and paste given assets folder, marker-icon.png and marker-shadow.png to src folder.
3. Run the application by "ng serve -o" and clear the caches in browser or try with incognito.